const userData = require("../MOCK_DATA.json");

const resolvers = {
  Query: {
    users: () => userData,
    user: (parent, args) => {
      // args.id * 1 - convert string to number
      const user = userData.find((user) => user.id === args.id * 1);
      return user;
    },
  },
  Mutation: {
    createUser: (parent, args) => {
      const user = args.input;
      user.id = userData.length + 1;
      userData.push(user);
      return user;
    },
  },
};

module.exports = { resolvers };
