const typeDefs = `#graphql
type User {
    id : ID!
    first_name: String!
    last_name: String!
    email : String!
    password : String!
  }

  type Query {
    users: [User!]!
    user(id : ID!) : User!
  }

  input CreateUserInput{
    first_name: String!
    last_name: String!
    email : String!
    password : String!
  }

  type Mutation {
    createUser(input : CreateUserInput!) : User!
  }
`;

module.exports = { typeDefs };
