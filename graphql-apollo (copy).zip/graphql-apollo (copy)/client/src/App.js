import { ApolloClient, InMemoryCache, ApolloProvider } from "@apollo/client";
import BasicTable from "./tableComponent";

const App = () => {
  const client = new ApolloClient({
    cache: new InMemoryCache(),
    uri: "http://localhost:5000/graphql",
  });
  return (
    <ApolloProvider client={client}>
      <div className="App">
        <BasicTable />
      </div>
    </ApolloProvider>
  );
};

export default App;
