import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useForm } from "react-hook-form";
import { useState } from "react";

import { useQuery, gql, useMutation } from "@apollo/client";

const getAllUsers = gql`
  query getAllUser {
    users {
      id
      first_name
      last_name
      email
    }
  }
`;

const AddUser = gql`
  mutation CreateUser($CreateUserInput: CreateUserInput!) {
    createUser(input: $CreateUserInput) {
      id
      first_name
      last_name
      email
    }
  }
`;
const BasicTable = () => {
  const { loading, data } = useQuery(getAllUsers);  

  const [createUser] = useMutation(AddUser);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const Handlesubmitform = (data) => {
    const { fname, lname, email, password } = data;

    createUser({
      variables: {
        CreateUserInput: {
          first_name: fname,
          last_name: lname,
          email,
          password,
        },
      },
    });
  };

  return (
    <React.Fragment>
      <form onSubmit={handleSubmit(Handlesubmitform)}>
        <TextField
          sx={{ mb: 5, mx: 2 }}
          label="Enter First Name"
          variant="standard"
          name="fname"
          {...register("fname", {
            required: "Required Field",
          })}
          error={!!errors?.fname}
          helperText={errors?.fname ? errors.fname.message : null}
        />
        <TextField
          sx={{ mb: 5, mx: 2 }}
          label="Enter Last Name"
          variant="standard"
          name="lname"
          {...register("lname", {
            required: "Required Field",
          })}
          error={!!errors?.lname}
          helperText={errors?.lname ? errors.lname.message : null}
        />
        <TextField
          sx={{ mb: 5, mx: 2 }}
          label="Enter Email"
          variant="standard"
          name="email"
          {...register("email", {
            required: "Required Field",
          })}
          error={!!errors?.email}
          helperText={errors?.email ? errors.email.message : null}
        />
        <TextField
          sx={{ mb: 5, mx: 2 }}
          label="Enter password"
          variant="standard"
          name="password"
          {...register("password", {
            required: "Required Field",
          })}
          error={!!errors?.password}
          helperText={errors?.password ? errors.password.message : null}
        />
        <Button type="submit" sx={{ mt: 2, mx: 5 }} variant="contained">
          Add
        </Button>
      </form>
      <div className="abc">
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell align="right">First Name</TableCell>
                <TableCell align="right">Last Name</TableCell>
                <TableCell align="right">Email</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {data?.users.map((row) => (
                <TableRow
                  key={row.first_name}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell component="th" scope="row">
                    {row.id}
                  </TableCell>
                  <TableCell align="right">{row.first_name}</TableCell>
                  <TableCell align="right">{row.last_name}</TableCell>
                  <TableCell align="right">{row.email}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
    </React.Fragment>
  );
};

export default BasicTable;
